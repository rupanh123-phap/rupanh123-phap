import xbmc
import threading
import json

from resources.libs.common.config import CONFIG
from resources.libs.common import logging

DEFAULT_SKINS = ['skin.estuary', 'skin.estouchy']


def _get_old(old_key):
    try:
        query = {
            "jsonrpc": "2.0",
            "method": "Settings.GetSettingValue",
            "params": {"setting": old_key},
            "id": 1
        }
        response = xbmc.executeJSONRPC(json.dumps(query))
        data = json.loads(response)
        return data.get("result", {}).get("value", None)
    except Exception as e:
        logging.log("Error in _get_old({0}): {1}".format(old_key, e))
        return None


def _set_new(new_key, value):
    try:
        query = {
            "jsonrpc": "2.0",
            "method": "Settings.SetSettingValue",
            "params": {"setting": new_key, "value": value},
            "id": 1
        }
        xbmc.executeJSONRPC(json.dumps(query))
    except Exception as e:
        logging.log("Error in _set_new({0}, {1}): {2}".format(new_key, value, e))


def _swap_skins(skin):
    _set_new('lookandfeel.skin', skin)
    return _dialog_watch()


def switch_to_skin(goto, title="Error"):
    result = _swap_skins(goto)

    if result:
        logging.log_notify(CONFIG.ADDONTITLE,
                           '[COLOR {0}]{1}: Thay Đổi Giao Diện Thành Công![/COLOR]'.format(CONFIG.COLOR2, title))
    else:
        logging.log_notify(CONFIG.ADDONTITLE,
                           '[COLOR {0}]{1}: Thay Đổi Giao Diện .. Đợi tí[/COLOR]'.format(CONFIG.COLOR2, title))

    return result


def skin_to_default(title):
    if _get_old('lookandfeel.skin') not in DEFAULT_SKINS:
        return switch_to_skin('skin.estuary', title)
    else:
        logging.log_notify(CONFIG.ADDONTITLE,
                           '[COLOR {0}]{1}Đang Sử Dụng Giao Diện[/COLOR]'.format(CONFIG.COLOR2, title))
        return False


def look_and_feel_data(do='save'):
    scan = [
        'lookandfeel.enablerssfeeds', 'lookandfeel.font', 'lookandfeel.rssedit',
        'lookandfeel.skincolors', 'lookandfeel.skintheme', 'lookandfeel.skinzoom',
        'lookandfeel.soundskin', 'lookandfeel.startupwindow', 'lookandfeel.stereostrength'
    ]

    if do == 'save':
        for item in scan:
            try:
                query = {
                    "jsonrpc": "2.0",
                    "method": "Settings.GetSettingValue",
                    "params": {"setting": item},
                    "id": 1
                }
                response = xbmc.executeJSONRPC(json.dumps(query))
                data = json.loads(response)
                if "result" in data and "value" in data["result"]:
                    CONFIG.set_setting(item.replace('lookandfeel', 'default'), data["result"]["value"])
                    logging.log("{0} saved to {1}".format(item, data["result"]["value"]))
            except Exception as e:
                logging.log("Error saving {0}: {1}".format(item, e))
    elif do == 'restore':
        for item in scan:
            try:
                value = CONFIG.get_setting(item.replace('lookandfeel', 'default'))
                if value is not None:
                    _set_new(item, value)
                    logging.log("{0} restored to {1}".format(item, value))
            except Exception as e:
                logging.log("Error restoring {0}: {1}".format(item, e))


def swap_us():
    try:
        setting = "addons.unknownsources"
        query = {
            "jsonrpc": "2.0",
            "method": "Settings.GetSettingValue",
            "params": {"setting": setting},
            "id": 1
        }
        response = xbmc.executeJSONRPC(json.dumps(query))
        data = json.loads(response)
        current = data.get("result", {}).get("value", False)

        new_value = not current
        threading.Thread(target=_dialog_watch).start()
        xbmc.sleep(200)

        _set_new(setting, new_value)

        state = "Enabled" if new_value else "Disabled"
        logging.log_notify(CONFIG.ADDONTITLE,
                           '[COLOR {0}]Unknown Sources:[/COLOR] [COLOR {1}]{2}[/COLOR]'.format(CONFIG.COLOR1, CONFIG.COLOR2, state))
        logging.log("Unknown Sources changed to {0}".format(state))
    except Exception as e:
        logging.log("Error in swap_us: {0}".format(e))


def _dialog_watch():
    x = 0
    while not xbmc.getCondVisibility("Window.isVisible(yesnodialog)") and x < 100:
        x += 1
        xbmc.sleep(100)

    if xbmc.getCondVisibility("Window.isVisible(yesnodialog)"):
        xbmc.executebuiltin('SendClick(yesnodialog, 11)')
        return True
    return False